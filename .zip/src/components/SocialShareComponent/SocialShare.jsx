import React from 'react'

const SocialShare = () => {
  return (
    <div>SocialShare</div>
  )
}

export default SocialShare